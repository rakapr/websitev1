   

import React from "react";

export default function Layout(){
   
    return(
      
      <section className="copyright-sec">
      <div className="copyright">Apricart E-Stores Pvt Ltd All rights reserved</div>
   </section>


    );
}